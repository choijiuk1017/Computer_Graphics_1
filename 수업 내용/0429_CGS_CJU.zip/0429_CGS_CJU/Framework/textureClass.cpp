#include "textureClass.h"
////////////////////////////////////////////////////////////////////////////////
// Filename: textureclass.cpp
////////////////////////////////////////////////////////////////////////////////
#include "textureclass.h"
#include "DDSTextureLoader.h"

using namespace DirectX;

TextureClass::TextureClass()
{
	m_texture1 = 0;
	m_texture2 = 0;
}


TextureClass::TextureClass(const TextureClass& other)
{
}


TextureClass::~TextureClass()
{
}


bool TextureClass::Initialize(ID3D11Device* device, const WCHAR* filename, const WCHAR* filename2)
{
	HRESULT result;

	// Load texture data from a file by using DDS texture loader.
	result = CreateDDSTextureFromFile(device, filename, nullptr, &m_texture1);
	if (FAILED(result)) return false;

	result = CreateDDSTextureFromFile(device, filename2, nullptr, &m_texture2);
	if (FAILED(result)) return false;

	return true;
}


void TextureClass::Shutdown()
{
	// Release the texture resource.
	if (m_texture1)
	{
		m_texture1->Release();
		m_texture1 = 0;
	}
	if (m_texture2)
	{
		m_texture2->Release();
		m_texture2 = 0;
	}

	return;
}


ID3D11ShaderResourceView* TextureClass::GetTexture1()
{
	return m_texture1;
}

ID3D11ShaderResourceView* TextureClass::GetTexture2()
{
	return m_texture2;
}