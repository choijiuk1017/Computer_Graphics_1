#pragma once
#include "CShape.h"


class CRectangle : public CShape
{
private:
	float m_w;
	float m_h;
protected:

	PAINTSTRUCT ps; // a structure need to paint the client area of a window
	HDC hdc; // a device context need for drawing on a window
	HWND hwnd;

public:
	CRectangle(float x, float y, float w, float h);

	~CRectangle();

	void Draw() const;
};

