#pragma once
class CCircle
{
};

