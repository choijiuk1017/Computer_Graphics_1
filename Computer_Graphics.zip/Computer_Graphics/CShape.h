#pragma once
#include<iostream>
#include<Windows.h>

using namespace std;

class CShape
{

private:
	float m_x;
	float m_y;
	
public:


	CShape(float x, float y) : m_x(x), m_y(y)
	{

	}

	~CShape()
	{

	}

	virtual void Draw() const
	{


	}
};